package com.abut.tunnel

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val orange = Color.rgb(245, 124, 0)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 36, 28, 24)
            setBackgroundColor(Color.rgb(255, 248, 240))
        }
        val title = TextView(this).apply {
            text = "ABUT TUNNEL VPN"
            textSize = 27f
            setTextColor(orange)
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "Secure connection • Your own server profiles"
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(0, 10, 0, 28)
        }
        val server = Spinner(this)
        server.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            listOf("Choose a server", "Add your own server profile"))
        val connect = Button(this).apply {
            text = "CONNECT"
            setBackgroundColor(orange)
            setTextColor(Color.WHITE)
        }
        val status = TextView(this).apply {
            text = "Status: VPN engine not configured"
            textSize = 16f
            setPadding(0, 24, 0, 8)
        }
        val note = TextView(this).apply {
            text = "Starter project only. No VPN tunnel is active yet. A supported VPN engine and working server configuration must be added before connecting."
            textSize = 13f
        }
        connect.setOnClickListener {
            status.text = "Status: Not connected — VPN engine is not installed"
        }
        root.addView(title)
        root.addView(subtitle)
        root.addView(server)
        root.addView(connect)
        root.addView(status)
        root.addView(note)
        setContentView(root)
    }
}
