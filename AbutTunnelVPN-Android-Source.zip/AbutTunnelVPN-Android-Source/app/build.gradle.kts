plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.abut.tunnel"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.abut.tunnel"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
