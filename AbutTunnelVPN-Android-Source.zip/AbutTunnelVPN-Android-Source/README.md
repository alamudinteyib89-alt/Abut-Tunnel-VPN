# Abut Tunnel VPN — Android starter project

This is a **starter source project**, not an installable APK and not a functioning VPN.

## Current contents
- Orange Abut Tunnel VPN starter screen
- Placeholder server selector and connect status
- Android project structure ready for further development

## Important work still required
A real VPN needs a maintained VPN tunnel engine (for example, a compatible sing-box/libbox integration), Android `VpnService` lifecycle and foreground notification handling, profile parsing, and valid server credentials/endpoints. No free public servers are included or verified. The Connect button intentionally does not claim to establish a tunnel.

## Build
Open this folder in Android Studio on a computer, allow Gradle sync, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

This project has not been built or device-tested in this environment.
